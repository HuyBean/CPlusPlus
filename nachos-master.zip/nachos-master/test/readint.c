/*
 * =====================================================================================
 *
 *       Filename:  readint.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/29/2013 09:12:48 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */
#include "syscall.h"
#include "copyright.h"
int main()
{
	int number = ReadInt();

}

