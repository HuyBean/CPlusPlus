/*
 * =====================================================================================
 *
 *       Filename:  help.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  03/31/2013 08:03:05 AM
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  YOUR NAME (), 
 *   Organization:  
 *
 * =====================================================================================
 */
#include "syscall.h"
#include "copyright.h"
int main()
{
	PrintString("Chao mung cac ban den voi nachos\n");
	PrintString("ascii: Chuong trinh hien bang ma ASCII\n");
	PrintString("bublesort: Chuong trinh sap xep buble sort\n");
	
	return 0;
}

