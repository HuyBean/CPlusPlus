# XV6 Source Code Reading -- File System

## Requirement

Code to read

* File system
  * [ ] `buf.h` (p.38)
  * [ ] `sleeplock.h` (p.39)
  * [ ] `fcntl.h` (p.39)
  * [ ] `stat.h` (p.40)
  * [ ] `fs.h` (p.40)
  * [ ] `file.h` (p.41)
  * [ ] `ide.c` (p.42)
  * [ ] `bio.c` (p.44)
  * [ ] `sleeplock.c` (p.46)
  * [ ] `log.c` (p.47)
  * [ ] `fs.c` (p.49)
  * [ ] `file.c` (p.58)
  * [ ] `sysfile.c` (p.60)
  * [ ] `exec.c` (p.66)
