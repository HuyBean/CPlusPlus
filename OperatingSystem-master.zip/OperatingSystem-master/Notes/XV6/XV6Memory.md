# XV6 Source Code Reading -- Memory

## Requirement

Code to read

* [ ] `kalloc.c` (p.31)
* [ ] `vm.c` (p.17)
