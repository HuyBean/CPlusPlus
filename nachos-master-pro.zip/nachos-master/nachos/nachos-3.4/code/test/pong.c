#include "syscall.h"
#include "copyright.h"

void main()
{
    int i=0;
    while(i++<1000)
    {
        PrintChar('B');
    }
}